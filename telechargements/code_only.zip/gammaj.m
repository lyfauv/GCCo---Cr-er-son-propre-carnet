%http://www.rpgroup.caltech.edu/courses/PBoC%20ASTAR/files_2011/Matlab/Image%20Analysis%20with%20Matlab.pdf
%p11
function Gj=gammaj(classe,im)
%im=imread('scary.png');
%im=rgb2gray(im);
%segm=[50 123];
%im=segmentation(im,segm);
Nj=countpixel(im,round(mean(classe)));
palette=unique(im);
tailleregion=[];
[n,m]=size(im);

for p=1:length(palette)
    ims=zeros(n,m);
    for i=1:n
        for j=1:m
            if im(i,j)==palette(p)
                ims(i,j)=200;
            end
        end
    end
    ims=mat2gray(ims);
    level=graythresh(ims);
    imb=im2bw(ims,level);
    [L,N]=bwlabel(imb);
    D=regionprops(L,'Area');
    darray=struct2array(D);
    tailleregion=[tailleregion(:); darray(:)];
end
Gj=length(find(tailleregion==Nj));
end

