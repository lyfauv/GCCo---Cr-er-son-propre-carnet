function NR=countregion(imag)
    
    listecoul=unique(imag);
    %donne les couleurs dans l'image, la palette quoi !

    n=size(imag,1);
    m=size(imag,2);
    NR=0;
    for c=1:length(listecoul) %on selectionne une couleur
        new2=imag;
        for i=1:n
            for j=1:m
                if imag(i,j)==listecoul(c) %on binairise sur cette couleur
                    new2(i,j)=2;
                end
                if imag(i,j)~=listecoul(c)
                    new2(i,j)=0;
                end
            end
        end
        %new2=rgb2gray(new2)
        
        %new2=im2bw(new2,1)
        cc = bwconncomp(new2,8); %connectivit� 8
        NR = NR + cc.NumObjects; %on compte le nb de r�gion avec cette coul
    end
end 


