function newim=segmentation(im,seuils)
    try 
    im=rgb2gray(im);
    end

    newim=im;
    segm=[0 seuils 255]; %rajoute le 0 et 255 � mes seuils
    for i=1:size(newim,1) % on parcours l'image
        for j=1:size(newim,2)
            for t=1:(length(segm)-1) 
                if newim(i,j)>=segm(t) && newim(i,j) <=segm(t+1) %si le pixelappartient � la classe ti, ti+1 
                    newim(i,j)=round((segm(t)+segm(t+1))/2); %on moyennise la classe
                end
            end
        end
    end
end