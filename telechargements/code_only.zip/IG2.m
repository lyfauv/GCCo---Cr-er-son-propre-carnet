function varargout = IG2(varargin)

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @IG2_OpeningFcn, ...
                   'gui_OutputFcn',  @IG2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before IG2 is made visible.
function IG2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to IG2 (see VARARGIN)

% Choose default command line output for IG2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes IG2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = IG2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% Bouton "update", qui va mettre � jour les informations donn�es par les autres �l�ments 
% et afficher les nouvelles images 
% nb_seuils = get(findobj('Tag', 'slider9'), 'Value'); % r�cup�re le nombre de seuils
% rho = get(findobj('Tag', 'slider10'), 'Value'); % r�cup�re le taux d'�vaporation
% tps_exec = get(findobj('Tag', 'radiobutton21'), 'Value') % 1 = court, 2 = long
% nb_fourmis = get(findobj('Tag', 'edit31'), 'Value'); % r�cup�re le nombre de fourmis
% iterations = get(findobj('Tag', 'edit32'), 'Value'); % r�cup�re le nombre d'it�rations
% trace1 = get(findobj('Tag', 'radiobutton23'), 'Value') % dis si le crit�re 1 pour la trace a �t� s�lectionn�
% trace2 = get(findobj('Tag', 'radiobutton24'), 'Value') % dis si le crit�re 2 pour la trace a �t� s�lectionn�
% trace3 = get(findobj('Tag', 'radiobutton25'), 'Value') % dis si le crit�re 3 pour la trace a �t� s�lectionn�
% alpha = get(findobj('Tag', 'edit33'), 'Value'); % r�cup�re la valeur du alpha
% beta = get(findobj('Tag', 'edit34'), 'Value'); % r�cup�re la valeur du beta
pathname = get(findobj('Tag', 'edit36'), 'String');
im = imread(pathname);
%set(findobj('Tag','edit31'),'String',nbfourmi)
%set(findobj('Tag','edit29'),'String',nb_seuils + 1)
RunACO()

function edit35_Callback(hObject, eventdata, handles)
% hObject    handle to edit35 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit35 as text
%        str2double(get(hObject,'String')) returns contents of edit35 as a double


% --- Executes during object creation, after setting all properties.
function edit35_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit35 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider9_Callback(hObject, eventdata, handles)
% slider du nombre de seuils
nb_seuils = round(get(findobj('Tag', 'slider9'), 'Value'))+1; 
%set(findobj('Tag','edit29'),'String',nb_seuils + 1)
set(findobj('Tag','edit29'),'Value',nb_seuils)
set(findobj('Tag','edit29'),'String',nb_seuils)
%edit29_Callback();
if get(findobj('Tag', 'radiobutton21'), 'Value')==1
    set(findobj('Tag', 'edit31'), 'Value', 30);
    set(findobj('Tag', 'edit31'), 'String', get(findobj('Tag', 'edit31'), 'Value'));
    set(findobj('Tag', 'edit32'), 'Value', [20 nb_seuils*50]);
    set(findobj('Tag', 'edit32'), 'String', mat2str(get(findobj('Tag', 'edit32'), 'Value')));
else 
    set(findobj('Tag', 'edit31'), 'Value', 50*(nb_seuils+1));
    set(findobj('Tag', 'edit31'), 'String', get(findobj('Tag', 'edit31'), 'Value'));
    set(findobj('Tag', 'edit32'), 'Value', [200 100*(nb_seuils)]);
    set(findobj('Tag', 'edit32'), 'String', mat2str(get(findobj('Tag', 'edit32'), 'Value')));
end
%edit31_Callback();
%edit32_Callback();
% hObject    handle to slider9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider



% --- Executes during object creation, after setting all properties.
function slider9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
set(hObject,'Value',0.2)
set(findobj('Tag', 'edit30'), 'Value', 0.2);
set(findobj('Tag', 'edit30'), 'String', get(findobj('Tag', 'edit30'), 'Value'));


% --- Executes on slider movement.
function slider10_Callback(hObject, eventdata, handles)
% hObject    handle to slider10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
evaporation = get(findobj('Tag', 'slider10'), 'Value'); 
evaporation = round(1000*evaporation)/1000;
set(findobj('Tag','edit30'),'String',evaporation);
set(findobj('Tag','edit30'),'Value',evaporation);
edit30_Callback();


% --- Executes during object creation, after setting all properties.
function slider10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function edit29_Callback(hObject, eventdata, handles)
% affiche la valeur du nombre de seuils
set(findobj('Tag','edit29'),'String',get(findobj('Tag','edit29'),'Value'))

% Hints: get(hObject,'String') returns contents of edit29 as text
%        str2double(get(hObject,'String')) returns contents of edit29 as a double


% --- Executes during object creation, after setting all properties.
function edit29_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit30_Callback(hObject, eventdata, handles)
% affiche la valeur de l'�vaporation

% Hints: get(hObject,'String') returns contents of edit30 as text
%        str2double(get(hObject,'String')) returns contents of edit30 as a double



% --- Executes during object creation, after setting all properties.
function edit30_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function radiobutton22_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
nbseuil= get(findobj('Tag','edit29'),'Value'); 
set(findobj('Tag', 'edit31'), 'Value', 50*(nbseuil+1));
set(findobj('Tag', 'edit31'), 'String', get(findobj('Tag', 'edit31'), 'Value'));
set(findobj('Tag', 'edit32'), 'Value', [200 100*(nbseuil)]);
set(findobj('Tag', 'edit32'), 'String', mat2str(get(findobj('Tag', 'edit32'), 'Value')));
%edit31_Callback()
%edit32_Callback()

function edit31_Callback(hObject, eventdata, handles)
% hObject    handle to edit31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%nbfourmi=get(findobj('Tag', 'edit31'), 'Value');
%set(findobj('Tag', 'edit32'), 'Value', [200 100*(nbseuil)]);
%set(findobj('Tag', 'edit32'), 'String', mat2str(get(findobj('Tag', 'edit32'), 'Value')));
%end
% Hints: get(hObject,'String') returns contents of edit31 as text
%        str2double(get(hObject,'String')) returns contents of edit31 as a double
%radiobutton21_Callback();
%set(findobj('Tag','edit31'),'String',get(findobj('Tag','edit31'),'Value'))


% --- Executes during object creation, after setting all properties.
function edit31_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit32_Callback(hObject, eventdata, handles)
% hObject    handle to edit32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit32 as text
%        str2double(get(hObject,'String')) returns contents of edit32 as a double
radiobutton21_Callback();
set(findobj('Tag','edit32'),'String',mat2str(get(findobj('Tag','edit32'),'Value')));


% --- Executes during object creation, after setting all properties.
function edit32_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit33_Callback(hObject, eventdata, handles)
% hObject    handle to edit33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject,'Value',str2num(get(hObject,'String')))
% Hints: get(hObject,'String') returns contents of edit33 as text
%        str2double(get(hObject,'String')) returns contents of edit33 as a double


% --- Executes during object creation, after setting all properties.
function edit33_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit34_Callback(hObject, eventdata, handles)
% hObject    handle to edit34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject,'Value',str2num(get(hObject,'String')))
% Hints: get(hObject,'String') returns contents of edit34 as text
%        str2double(get(hObject,'String')) returns contents of edit34 as a double


% --- Executes during object creation, after setting all properties.
function edit34_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
    [FileName1,PathName] = uigetfile('*.jpg','Select the picture file');
    set(findobj('Tag','edit36'),'String',strcat(PathName,FileName1))
    %set(findobj('Tag', 'axes13'), imread(FileName1))
    %axes1 = imagesc(imread(FileName1))
    imprint=imread(get(findobj('Tag','edit36'),'String'));
    try 
        imprint=rgb2gray(imprint);
    end

axes(handles.axes13);
%axes13.title='image upload�e'
imagesc(imprint);

    



function edit36_Callback(hObject, eventdata, handles)
    

% Hints: get(hObject,'String') returns contents of edit36 as text
%        str2double(get(hObject,'String')) returns contents of edit36 as a double


% --- Executes during object creation, after setting all properties.
function edit36_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over radiobutton21.
function radiobutton21_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to radiobutton21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over radiobutton22.
function radiobutton22_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to radiobutton22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in radiobutton21.
function radiobutton21_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
nb_seuils = get(findobj('Tag','edit29'),'Value'); 
set(findobj('Tag', 'edit31'), 'Value', 30);
set(findobj('Tag', 'edit31'), 'String', get(findobj('Tag', 'edit31'), 'Value'));
set(findobj('Tag', 'edit32'), 'Value', [20 nb_seuils*50]);
set(findobj('Tag', 'edit32'), 'String', mat2str(get(findobj('Tag', 'edit32'), 'Value')));



function edit37_Callback(hObject, eventdata, handles)
% hObject    handle to edit37 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit37 as text
%        str2double(get(hObject,'String')) returns contents of edit37 as a double


% --- Executes during object creation, after setting all properties.
function edit37_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit37 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
