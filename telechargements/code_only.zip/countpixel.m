function pix=countpixel(image,coul)
pix=0;    
for i =1:size(image,1)
        for j =1:size(image,2)
            if image(i,j)==coul
                pix= pix+1;
            end
        end
end
end
