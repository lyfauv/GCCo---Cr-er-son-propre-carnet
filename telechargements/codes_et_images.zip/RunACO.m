%importation de l'image
try 
    im=rgb2gray(im);
end

%axes(handles.axes13)
%imagesc(im)
rho=get(findobj('Tag', 'edit30'), 'Value'); % r�cup�re le taux d'�vaporation
nbseuil=get(findobj('Tag', 'edit29'), 'Value');

transi=triu(ones(256))-eye(256);%initialisation table ph�romonale
MVarCrit=0 ;%initialisation du crit�re � optimiser
    
%mode long :
%N=50*(nbseuil+1) ;%nb de fourmis
%Nbimax1=100*(N-1); %nb total d'it�ration max
%Nbimax2=200 ;%nb d'it�rations sans changement mvarcrit

%mode court :
%N=20 ;
%Nbimax1=10*(nbseuil); %nb total d'it�ration max
%Nbimax2=20 ;%nb d'it�rations sans changement mvarcrit

N=get(findobj('Tag', 'edit31'), 'Value');
limite = get(findobj('Tag', 'edit32'), 'Value');
Nbimax2=limite(1);
Nbimax1=limite(2);
%[Nbimax2 Nbimax1]=get(findobj('Tag', 'edit32'), 'Value');
%Nbimax2=get(findobj('Tag', 'edit30'), 'Value');

alpha=str2num(get(findobj('Tag', 'edit33'), 'String'));
beta=str2num(get(findobj('Tag', 'edit34'), 'String'));


Fourmis=zeros(N,2);%initialisation de la bdd des fourmis
win=[0 0];
nb1=0, nb2=0;

while nb1<Nbimax1 && nb2<Nbimax2

    for i=1:N
        t=tupleseuilparam(transi,nbseuil,alpha,beta); %on simule des seuils � partir de transi  
        new=segmentation(im,t); 
        v=MVar(t,new,im);
        if v>win(end) %Maximisation de la variance
            win= [t v];
            nb2=0;
        end
        % TRACE PHEROMONALE
        tup=[0 t 255];
        for s=1:(length(tup)-1)
            if get(findobj('Tag', 'radiobutton23'), 'Value')==1 
                %si la trace choisis est le MVar
                transi(tup(s)+1,tup(s+1)+1)=transi(tup(s)+1,tup(s+1)+1)+v; %proposition
            end
            if get(findobj('Tag', 'radiobutton24'), 'Value')==1 
                %Cas de l'article ou la trace est fonction de la somme des
                %seuils propos�s
                transi(tup(s)+1,tup(s+1)+1)=transi(tup(s)+1,tup(s+1)+1)+(1/sum(tup));
            end
            if get(findobj('Tag', 'radiobutton25'), 'Value')==1 
                %Cas hybride entre optimisation et reproduction des
                %r�sultats
                transi(tup(s)+1,tup(s+1)+1)=transi(tup(s)+1,tup(s+1)+1)+(v/(sum(tup)^2));
            end
        end

       
    end
    %�vaporation
    transi=transi.*(1-rho);
    set(findobj('Tag', 'text38'), 'String', strcat(num2str(nb1),'%'));
    set(findobj('Tag', 'text38'), 'Value', nb1);
    yolo=get(findobj('Tag', 'text38'), 'String');
    yolo
    nb1=nb1+1
    strcat(num2str(nb1),'%');
    set(findobj('Tag', 'text39'), 'String', strcat(num2str(nb2),'%'));
    nb2=nb2+1
    set(findobj('Tag', 'edit38'), 'String', nb1);
end

t=win(1:end-1)
%new=segmentation(im,t);

%NR=countregion(new);
%NR
%imagesc(new)
win


axes(handles.axes14);
title('image segment�e')
im2=segmentation(im,t);
imagesc(im2);
axes(handles.axes15);
title(mat2str(win))
imhist(im)
hold all
for i=1:length(t)
    plot([t(i) t(i)],[0 max(imhist(im))],'r-') ;
end
set(findobj('Tag', 'edit38'), 'String', mat2str(win));

%if length(Dataviz(1,:))==5
%    Dataviz(isnan(Dataviz)) = 0 ;
%    figure();
%    scatter3(Dataviz(:4000,1),Dataviz(:4000,2),Dataviz(:4000,3),(Dataviz(:4000,4)+10^-15)*10^10,Dataviz(:4000,5));
%end



