function y=simustep(loiproba)
    a=rand*sum(loiproba); %genere un alea entre 0 et la somme des proba de la loi
    res=0;
    y=0;
    i=1;
    while (y==0) && (i<=length(loiproba))
        res = res + loiproba(i);
        if (a<=res) && (res ~= 0)
            y=i;
        end
        i = i+1;
    end
end