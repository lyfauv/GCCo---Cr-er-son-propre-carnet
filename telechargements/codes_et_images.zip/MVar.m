function varinter=MVar(seuils,imagesegm,image)
    nvs=[0 seuils 256];
    varinter = 0;
    alpha = 1/(size(image,1)*size(image,2)*1000);
    alpha = alpha * sqrt(countregion(imagesegm));
    for s=1:length(nvs)-1
        betaj = 1/(1+log(countpixel(imagesegm,round((nvs(s)+nvs(s+1))/2))));
        classe=[nvs(s) nvs(s+1)];
        varintra=sigmaj(image,classe);
        gamma = gammaj(classe,imagesegm); 
        if isnan(gamma) 
            gamma=0 
        end
        varinter = varinter + (betaj*varintra+gamma);
    end
    varinter = varinter* alpha;
    if isnan(varinter) 
        varinter=0 ;
    end
end