function nickie=sigmaj(image,classe)
bdd=[];    
    for i=1:size(image,1)
        for j=1:size(image,2)
            if image(i,j)>=classe(1) && image(i,j)<=classe(2) %si le pixel de l'im d'origine est dans la classe
                bdd(end+1) = image(i,j);
            end
        end
    end
nickie = var(bdd);
end