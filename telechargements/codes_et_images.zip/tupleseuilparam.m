function y=tupleseuil(transi,nbseuil,alpha,beta)
    y=zeros(1,nbseuil); %matrice de taille nbseuil qui va accueillir les seuils
    seuilrestant=nbseuil; %lenombre de seuils qui reste � determiner
    a=1;
    for i=1:nbseuil %pour chaque seuil
        loiproba=zeros(1,256); 
        for j=a+1:256-seuilrestant %pn peut se d�placer en avant mais en gardant de laplace pour les seuils restants
            %loiproba(j)=transi(a,j); % on lit juste les tau(i,j)
            nu=1/(j-a); %la visibilit�
            loiproba(j)=((transi(a,j))^alpha)*((nu)^beta); % on a tau(i,j)^alpha*visibilit�(i,j)^beta
        end
        y(i) = simustep(loiproba); % a + simustep ?
        a = y(i);
        seuilrestant = nbseuil-i ;
    end
end