%importation de l'image
%c;
im=imread('pathos.png');
try 
    im=rgb2gray(im);
end
%imagesc(im);
figure()
rho=0.2; %taux d'evaporation
nbseuil=3;

transi=triu(ones(256))-eye(256);%initialisation table ph�romonale
MVarCrit=0 ;%initialisation du crit�re � optimiser
N=30
%N=50*(nbseuil+1) ;%nb de fourmis
%Nbimax1=100*(N-1); %nb total d'it�ration max
%Nbimax2=200 ;%nb d'it�rations sans changement mvarcrit

Nbimax1=50*(N-1); %nb total d'it�ration max
Nbimax2=20 ;%nb d'it�rations sans changement mvarcrit


N=20 ;
%Nbimax1=10*(nbseuil); %nb total d'it�ration max
%Nbimax2=20 ;%nb d'it�rations sans changement mvarcrit

Fourmis=zeros(N,2);%initialisation de la bdd des fourmis
win=[0 0];
nb1=0, nb2=0;
Dataviz=zeros(Nbimax1*N,nbseuil+2);%evolution de la solution
dv=1; %index de dataviz

while nb1<Nbimax1 && nb2<Nbimax2

    for i=1:N

        t=tupleseuil(transi,nbseuil); %on simule des seuils � partir de transi
        %Fourmis(i,1)=t;
        for viz=1:nbseuil
            Dataviz(dv,viz)=t(viz); %concerve les donn�es des tuples propos�s par les fourmis
        end
        
        new=segmentation(im,t);

        %Fourmis(i,2)=MVar(t,new,im);
        v=MVar(t,new,im);
        Dataviz(dv,end-1)=v; %prend le MVar
        Dataviz(dv,end)=i; %prend le nombre de tour execut�s
        dv=dv+1;
        if v>win(end) %Maximisation de la variance
            win= [t v];
            nb2=0;
        end

        %la trace ph�romonale
        tup=[0 t 255];
        %tup=[0 t 256];
        for s=1:(length(tup)-1)
            %transi(tup(s)+1,tup(s+1)+1)=transi(tup(s)+1,tup(s+1))+(1+1/256);
            tup(s)+1 ;
            tup(s+1)+1 ;
            %transi(tup(s)+1,tup(s+1)+1)=transi(tup(s)+1,tup(s+1)+1)+(v/(sum(tup)^2)); %proposition
            
            %ARTICLE:
            transi(tup(s)+1,tup(s+1)+1)=transi(tup(s)+1,tup(s+1)+1)+(1/sum(tup));
            
            %transi(tup(s)+1,tup(s+1)+1)=transi(tup(s)+1,tup(s+1))+(1/sum(t)+1);
            %vraie valeur
        end

       
    end
    %�vaporation
    transi=transi.*(1-rho);
    
    'nb1'
    nb1=nb1+1
    'nb2'
    nb2=nb2+1
end

t=win(1:end-1)
%new=segmentation(im,t);

%NR=countregion(new);
%NR
%imagesc(new)
win

subplot(2,2,1);
imagesc(im);
subplot(2,2,3);
im2=segmentation(im,t);
imagesc(im2);
subplot(2,2,4);
imhist(im)
hold all
for i=1:length(t)
    plot([t(i) t(i)],[0 max(imhist(im))],'r-') ;
end



%if length(Dataviz(1,:))==5
%    Dataviz(isnan(Dataviz)) = 0 ;
%    figure();
%    scatter3(Dataviz(:4000,1),Dataviz(:4000,2),Dataviz(:4000,3),(Dataviz(:4000,4)+10^-15)*10^10,Dataviz(:4000,5));
%end



